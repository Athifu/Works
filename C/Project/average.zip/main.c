
#include <stdio.h>

int main(){
    float num1,num2,num3;
    float average;
    float sum;
    printf("welcome to our project\n");
    printf("enter 3 number to find average\n");
    scanf("%f%f%f",&num1,&num2,&num3);
    sum =num1+num2+num3;
    average=(sum)/3;
    printf ("result: %f",average);
    return 0;
}
