#include <stdio.h>

int main()
{
    int i,val;
    int sum = 0;
    printf("Enter a number to find the even number   : ");
    scanf("%d",&val);
    for(i=2;i<=val;i++){
        if(i%2==0){
            printf(" \n%d\n",i);
        }
    }
    

    return 0;
}
