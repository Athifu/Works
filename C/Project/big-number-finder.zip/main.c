
#include <stdio.h>

int main()
{
    int num1,num2;
    
    printf("enter two number ");
    scanf("%d%d",&num1,&num2);
    if(num1>num2){
        printf("Grates number is %d",num1);
    }else{
        printf("Gratest number is %d",num2);
    }
    

    return 0;
}
