
#include <stdio.h>

int main()
{
    int limit , i;
    int array[100],sum=0;
    printf("Enter arary limit  :");
    scanf("%d",&limit);
    
    printf("Enter the Values :");
    for(i=0;i<limit;i++){
        scanf("%d",&array[i]);
    }
    for(i=0;i<limit;i++){
        sum =sum+array[i];
    }
    printf("Tatal sum : %d",sum);
    

    return 0;
}
