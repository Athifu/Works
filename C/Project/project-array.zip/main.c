#include <stdio.h>

int main()
{
    int array[100];
    int limit;
    int i;
    printf("Enter Array limit");
    scanf("%d",&limit);
    printf("Enter arrey values");
    for(i=0;i<limit;i++){
        scanf("%d",&array[i]);
    }
    printf("Enter Values are ");
    for(i=0;i<limit;i++){
        printf("%d\t",array[i]);
    }
    return 0;
}
