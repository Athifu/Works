
#include <stdio.h>

int main()
{
    int choice;
    printf("1 for biriyani\n2for dosha\n 3 for porotta\n 4 for Mandhi\n please enter your choice");
    scanf("%d",&choice);
    switch(choice){
        case 1:
        printf("You have Selected Biriyani");
        break;
        case 2:
        printf("you have Enterd dashaa");
        break;
        case 3:
        printf("you have selected porotta");
        break ;
        case 4:
        printf("you have Enterd Mandhi");
        break ;
        default:
        printf("you are a folllllll");
    }

    return 0;
}