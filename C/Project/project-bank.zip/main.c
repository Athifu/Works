#include <stdio.h>

int main()
{
    int password;
    int choice , repeat , i , j;
    int account_balance = 1500 , mini[10];
    int  deposit_amount ;
    int  withdraw_amount ;
    printf("                                             Welcome to ABCD bank \n          ");
    printf("Enter your password  :");
    scanf("%d",&password);
        if(1234==password){
 
            for(; ;){
                    printf("1 for Deposit\n2 for wthdraw\n3 for balance enquiry\n4 for mini satement\n please selesct your option :");
                    scanf("%d",&choice); 
                 switch(choice){  
                     case 1: 
                     printf("Enter the Amount To Deposit :");
                     scanf("%d",&deposit_amount);
                     account_balance = account_balance + deposit_amount ;
                     printf("Current amount : %d\n",account_balance);
                     mini[i] = deposit_amount;
                     i++;
                     break;
                     case 2:
                     printf("Enter the Amount to withdraw :");
                     scanf("%d",&withdraw_amount);
                     account_balance =account_balance - withdraw_amount ;
                     printf("Current Amount : %d\n",account_balance);
                     mini[i] =  (withdraw_amount *- 1);
                     i++;
                     break;
                     case 3:
                     printf("Account Balance :%d\n",account_balance);
                     break;
                     case 4:
                     printf("Checking your bank Statment .......\n");
                     for(i=0;i<choice;i++){
                         printf("  %d\n",mini[i]);
                     }
                     break;
                     }
               printf("Do you want to continue ? \nYes = 1\nNo = 2\n please Enter your choice  :");
               scanf("%d",&repeat);
               if(repeat==2){
                   break;
               }
             }
          
        }else{
            printf("You have Enter Wrong password try agian");
        }
    return 0;
}   
