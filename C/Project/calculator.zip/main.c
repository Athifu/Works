

#include <stdio.h>

int main()
{
    float num1, num2;
    int num3;
    int result ;
    printf("Welcome to our project\n");
    
    printf("Enter two number\n");
    
    scanf("%f%f", &num1 , &num2 );
    
    printf("\n1 for addition\n 2 for suptraction\n 3 for devition\n 4 for maltiplication\n enter ypur choice\n");
    -
    scanf("%d",&num3);  
    
    if(num3 == 1){
        result = num1 +num2 ;
    }else if (num3 = 2){
        result = num1 -num2 ;
    }else if (num3 = 3){
        result = num1/num2 ;
    }else if (num3 = 4){
        result = num1*num2 ;
    }else{
        printf("your are a fool!!");
    }
         printf("Result : %d",result);
    };

    return 0;
}




