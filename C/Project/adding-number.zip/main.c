
#include <stdio.h>

int main() {
    int num1,num2;
    int sum;
    printf("Enter two number\n");
    scanf("%d%d",&num1,&num2);
    sum = num1+num2;
    printf("result\n%d",sum);
    return 0;
}