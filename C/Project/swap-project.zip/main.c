
#include <stdio.h>

int main()
{
    int num1,num2;
    int temp;
    printf("enter two number to swap");
    scanf("%d%d",&num1,&num2);
    temp = num1;
    num1=num2;
    num2=temp;
    printf("result num1 ; %d num2 ;%d",num1 ,num2);
    return 0;
}
